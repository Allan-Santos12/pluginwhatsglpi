<?php

define('APP_URL', "https://app.chatcorp.com.br");
define('API_URL', APP_URL . "/api");

define('HU3_PLUGIN_VERSION', '1.6.2');
