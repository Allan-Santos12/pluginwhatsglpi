<?php

const TEMPLATES = [
  "ChatCorp: Novo chamado" => [
    "type"          => "Ticket",
    "event"         => "new",
    "targets"        => [
      1 => [3]
    ],
    "subject"       => "Novo chamado",
    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi aberto com sucesso!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Descrição:* ##ticket.content##

*Status:* ##ticket.status##

*Para interagir com ele basta clicar no link:* ##ticket.url##
*Para adicionar um acompanhamento, use o recurso de resposta do WhatsApp nesta mensagem.*

Obrigado'
  ],
  "ChatCorp: Novo acompanhamento" => [
    "type"          => "Ticket",
    "event"         => "add_followup",
    "targets"        => [
      1 => [3]
    ],
    "subject"       => "Novo acompanhamento",
    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi respondido!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Informações adicionadas:*

##FOREACHfollowups##

[_##followup.date##_] *##followup.author##* respondeu: ##followup.description##

##ENDFOREACHfollowups##

*Status:* ##ticket.status##

*Para interagir com ele basta clicar no link:* ##ticket.url##
*Para adicionar um acompanhamento, use o recurso de resposta do WhatsApp nesta mensagem.*

Obrigado'
  ],
  "ChatCorp: Chamado encerrado" => [
    "type"          => "Ticket",
    "event"         => "closed",
    "targets"        => [
      1 => [3]
    ],
    "subject"       => "Chamado encerrado",
    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi encerrado!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Status:* ##ticket.status##

Muito obrigado por utilizar nossos serviços'
  ],
  "ChatCorp: Aguardando validação" => [
    "type"          => "Ticket",
    "event"         => "validation",
    "targets"        => [
      1 => [3]
    ],
    "subject"       => "Aguardando validação",
    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi solucionado e aguarda a sua validação!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Informações da solução:* ##ticket.solution.description##

*Status:* ##ticket.status##

*Para aprovar ou reprovar a solução, clique no link:* ##ticket.urlapprove##
*Para adicionar um acompanhamento, use o recurso de resposta do WhatsApp nesta mensagem.*

Obrigado'
  ],
  "ChatCorp: Chamado solucionado" => [
    "type"          => "Ticket",
    "event"         => "solved",
    "targets"        => [
      1 => [3]
    ],
    "subject"       => "Chamado solucionado",
    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi solucionado em ##ticket.solvedate##!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Informações da solução:* ##ticket.solution.description##

*Status:* ##ticket.status##

*Para interagir com ele basta clicar no link:* ##ticket.url##

Obrigado'
  ],
  "ChatCorp: Pesquisa de satisfação" => [
    "type"          => "Ticket",
    "event"         => "satisfaction",
    "targets"        => [
      1 => [3]
    ],
    "subject"       => "Chamado solucionado",
    "content_text"  => '⭐⭐⭐⭐⭐

Olá *##ticket.authors##* avalie o atendimento recebido referente ao seu chamado com os dados abaixo:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Status:* ##ticket.status##

*Clique no link abaixo para avaliar o atendimento:*
##ticket.urlsatisfaction##

A sua avaliação é muito importante para nós.

Obrigado'
  ],
];
