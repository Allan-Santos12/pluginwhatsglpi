<?php

class PluginChatcorpNotificationWhatsapp implements NotificationInterface
{
  static function check($value, $options = [])
  {
    //Does nothing, but we could check if $value is actually what we expect as a phone number to send ChatCorp.
    return true;
  }

  static function testNotification()
  {
    return true;
  }

  function sendNotification($options = array())
  {
    try {
      $data = [
        'itemtype'                             => $options['_itemtype'] ?? $options['itemtype'] ?? '',
        'items_id'                             => $options['_items_id'] ?? $options['items_id'] ?? 0,
        'notificationtemplates_id'             => $options['_notificationtemplates_id'] ?? $options['notificationtemplates_id'] ?? 0,
        'entities_id'                          => $options['_entities_id'] ?? $options['entities_id'] ?? 0,
        'sendername'                           => '',
        'sender'                               => $options['sender'] ?? 'Undefined sender',
        'name'                                 => $options['subject'] ?? 'Undefined subject',
        'body_text'                            => $options['content_text'] ?? 'Undefined content_text',
        'recipient'                            => $options['recipient'] ?? 'Undefined recipient',
        'recipientname'                        => $options['recipientname'] ?? 'Undefined recipient name',
        'mode'                                 => PluginChatcorpNotificationWhatsappSetting::MODE_WHATSAPP
      ];

      $notificationqueue = new QueuedNotification();

      // Adicionar notificação na notificationqueue
      if (!$notificationqueue->add(Toolbox::addslashes_deep($data))) {
        Session::addMessageAfterRedirect(__('Ocorreu um erro ao adicionar a notificação na fila'), true, ERROR);
        return false;
      } else {
        //TRANS to be written in logs %1$s is the to email / %2$s is the subject of the mail
        // Adicionar notificação no log do GLPI
        Toolbox::logInFile(
          "notification",
          sprintf(
            __('%1$s: %2$s'),
            sprintf(
              __('A whatsapp notification to %s was added to queue'),
              $options['to'] ?? 'Undefined recipient'
            ),
            $options['subject'] ?? 'Undefined subject' . "\n"
          )
        );
      }
    } catch (Exception $e) {
      Session::addMessageAfterRedirect(__('Ocorreu um erro ao adicionar a notificação na fila:' . $e->getMessage()), true, ERROR);
    }

    return true;
  }
}
