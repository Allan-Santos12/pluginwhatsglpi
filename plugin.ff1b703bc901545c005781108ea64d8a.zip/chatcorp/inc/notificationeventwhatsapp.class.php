<?php

require_once(__DIR__ . '/constants.php');
require_once(__DIR__ . '/../utils/string.php');

// Classe para gerar os eventos da notificação
class PluginChatcorpNotificationEventWhatsapp implements NotificationEventInterface
{
  static public function getTargetFieldName()
  {
    return 'users_id';
  }

  /**
   * @param mixed $event
   * @param CommonGLPI|CommonDBTM $item
   * @param array $options
   * @param string $label
   * @param array $data
   * @param NotificationTarget $notificationtarget
   * @param NotificationTemplate $template
   * @param mixed $notify_me
   * @return void
   */
  static public function raise(
    $event,
    $item,
    array $options,
    $label,
    array $data,
    NotificationTarget $notificationtarget,
    NotificationTemplate $template,
    $notify_me,
    $emitter = null
  ) {
    // Esse método é executado pelo GLPi para adicionar uma notificação na fila
    global $DB, $CFG_GLPI;

    if ($CFG_GLPI['notifications_' . $options['mode']]) {
      $entity = $notificationtarget->getEntity();
      if (isset($options['processed'])) {
        $processed = &$options['processed'];
        unset($options['processed']);
      } else {
        $processed = [];
      }
      $notprocessed = [];

      $dbu = new DbUtils();

      $targets = $dbu->getAllDataFromTable(
        'glpi_notificationtargets',
        ['notifications_id' => $data['id']]
      );

      // Para cada alvo de notificação
      foreach ($targets as $target) {
        // Pega os usuários que são afetados por essa notificação
        $notificationtarget->addForTarget($target, $options);
      }

      // var_dump($notificationtarget->getTargets());
      // die;
      foreach ($notificationtarget->getTargets() as $users_infos) {
        $user = $dbu->getAllDataFromTable(
          'glpi_users',
          ['id' => $users_infos['users_id']]
        );

        $key = $users_infos[static::getTargetFieldName()];
        if (
          $label
          || $notificationtarget->validateSendTo($event, $users_infos, $notify_me, $emitter)
        ) {
          // Caso o usuário não tenha sido notificado
          if (!isset($processed[$users_infos['language']][$key])) {
            // Se a linguagem que o usuário configurou no GLPI for a mesma do template
            if (isset($notprocessed[$users_infos['language']][$key])) {
              unset($notprocessed[$users_infos['language']][$key]);
            }

            $options['item'] = $item;
            if ($tid = $template->getTemplateByLanguage(
              $notificationtarget,
              $users_infos,
              $event,
              $options
            )) {
              // Enviar notificação para usuário
              if ($label == '') {
                $send_data = $template->getDataToSend(
                  $notificationtarget,
                  $tid,
                  $key,
                  $users_infos,
                  $options
                );
                $send_data['_notificationtemplates_id'] = $data['notificationtemplates_id'];
                $send_data['_itemtype']                 = $item->getType();
                $send_data['_items_id']                 = method_exists($item, "getID")
                  ? $item->getID()
                  : 0;
                $send_data['_entities_id']              = $entity;
                $send_data['mode']                      = $data['mode'];

                // Se o usuário tiver o campo "mobile" configurado (campo de número do celular)
                if (isset($user[$users_infos['users_id']]['mobile']) && !empty($user[$users_infos['users_id']]['mobile'])) {
                  $send_data['recipient'] = $user[$users_infos['users_id']]['mobile'];
                  $send_data['recipientname'] = $user[$users_infos['users_id']]['name'];

                  // Verifica se o usuário está em alguma entidade que foi configurada no plugin
                  // e pega o número que está sendo usado
                  $pluralizedTableName = getPluralChatcorpTableName('chatcorp');
                  $queryWithEntitiesList = "SELECT wts.number
                  FROM glpi_plugin_chatcorp_$pluralizedTableName AS wts
                      LEFT JOIN glpi_plugin_chatcorp_entities AS e
                          ON e.entity_id = {$user[$users_infos['users_id']]['entities_id']}
                  WHERE wts.id = e.wts_id OR wts.use_all_entities = 1";

                  foreach ($DB->request($queryWithEntitiesList) as $row) {
                    if ($row['number']) {
                      $send_data['sender'] = $row['number'];
                      Notification::send($send_data);
                    }
                  }
                }
              } else {
                $notificationtarget->getFromDB($target['id']);
                echo "<tr class='tab_bg_2'><td>" . $label . "</td>";
                echo "<td>" . $notificationtarget->getNameID() . "</td>";
                echo "<td>" . sprintf(
                  __('%1$s (%2$s)'),
                  $template->getName(),
                  $users_infos['language']
                ) . "</td>";
                echo "<td>" . $options['mode'] . "</td>";
                echo "<td>" . $key . "</td>";
                echo "</tr>";
              }
              $processed[$users_infos['language']][$key]
                = $users_infos;
            } else {
              $notprocessed[$users_infos['language']][$key]
                = $users_infos;
            }
          }
        }
      }
    }

    unset($processed);
    unset($notprocessed);
  }

  static public function getTargetField(&$data)
  {
    $field = self::getTargetFieldName();

    if (!isset($data[$field])) {
      //Missing users_id; set to null
      $data[$field] = null;
    }

    return $field;
  }

  static public function canCron()
  {
    return true;
  }

  static public function getAdminData()
  {
    //no phone available for global admin right now
    return false;
  }

  static public function getEntityAdminsData($entity)
  {
    global $DB, $CFG_GLPI;

    $iterator = $DB->request([
      'FROM'   => 'glpi_entities',
      'WHERE'  => ['id' => $entity]
    ]);

    $admins = [];

    while ($row = version_compare(GLPI_VERSION, '10.0.0', '<') ? $iterator->next() : $iterator->current()) {
      $admins[] = [
        'language'  => $CFG_GLPI['language'],
        'phone'     => $row['phone_number']
      ];
    }

    return $admins;
  }

  static public function send(array $data) // Enviar notificação
  {
    global $DB;
    $pluralizedTableName = getPluralChatcorpTableName('chatcorp');

    foreach ($data as $row) {
      $current = new QueuedNotification();
      $sender = $row['sender'];
      $recipient = $row['recipient'];

      $iterator = $DB->request("SELECT token FROM glpi_plugin_chatcorp_$pluralizedTableName WHERE number = '{$sender}'");

      $wts = version_compare(GLPI_VERSION, '10.0.0', '<') ? $iterator->next() : $iterator->current();

      $message = $row['body_text'];
      $body = [
        "number" => $recipient,
        "message" => $message,
      ];

      if ($row["items_id"] > 0) {
        $body["integrationId"] = $row['items_id'];
      }

      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => API_URL . '/srvc/w/send/text',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => array(
          "apikey: {$wts['token']}"
        ),
      ));

      $resp = json_decode(curl_exec($curl));

      if ($resp->success && $row["items_id"] > 0) {
        $query = "INSERT INTO `glpi_plugin_chatcorp_messages`
                        (`message_id`, `ticket_id`)
                VALUES ('{$resp->messageId}', '{$row["items_id"]}')";
        $DB->queryOrDie($query, $DB->error());
      }

      curl_close($curl);

      $current->delete(['id' => $row['id']]); // Deletar notificação do notificationqueue quando finalizar
    }

    return true;
  }
}
