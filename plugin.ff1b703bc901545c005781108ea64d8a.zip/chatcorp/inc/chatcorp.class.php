<?php

require_once(__DIR__ . '/constants.php');
require_once(__DIR__ . '/../utils/string.php');
require_once(__DIR__ . '/template.class.php');

// Classe principal
class PluginChatcorpChatcorp extends CommonDBTM
{
  static $tags = '[CHATCORP_ID]';

  // Should return the localized name of the type
  static function getTypeName($nb = 0)
  {
    return 'ChatCorp';
  }

  static function canCreate()
  {
    return $_SESSION["glpi_plugin_chatcorp_profile"]['chatcorp'] == 'w';
  }

  static function canView()
  {
    return $_SESSION["glpi_plugin_chatcorp_profile"]['chatcorp'] == 'w';
  }

  /**
   * @see CommonGLPI::getMenuName()
   **/
  static function getMenuName()
  {
    return __('Chat Corp');
  }

  static function showFromArray($name, array $elements, $options = [])
  {

    $param['value']               = '';
    $param['values']              = [''];
    $param['class']               = '';
    $param['tooltip']             = '';
    $param['option_tooltips']     = [];
    $param['used']                = [];
    $param['readonly']            = false;
    $param['on_change']           = '';
    $param['width']               = '';
    $param['multiple']            = false;
    $param['size']                = 1;
    $param['other']               = false;
    $param['rand']                = mt_rand();
    $param['emptylabel']          = '-----';
    $param['display_emptychoice'] = false;
    $param['disabled']            = false;
    $param['noselect2']           = false;

    if (is_array($options) && count($options)) {
      if (isset($options['value']) && strlen($options['value'])) {
        $options['values'] = [$options['value']];
        unset($options['value']);
      }
      foreach ($options as $key => $val) {
        $param[$key] = $val;
      }
    }

    if ($param['other'] !== false) {
      $other_select_option = $name . '_other_value';
      $param['on_change'] .= "displayOtherSelectOptions(this, \"$other_select_option\");";

      // If $param['other'] is a string, then we must highlight "other" option
      if (is_string($param['other'])) {
        if (!$param["multiple"]) {
          $param['values'] = [$other_select_option];
        } else {
          $param['values'][] = $other_select_option;
        }
      }
    }

    $param['option_tooltips'] = Html::entities_deep($param['option_tooltips']);

    if ($param["display_emptychoice"] && !$param["multiple"]) {
      $elements = [0 => $param['emptylabel']] + $elements;
    }

    if ($param["multiple"]) {
      $field_name = $name . "[]";
    } else {
      $field_name = $name;
    }

    $output = '';
    // readonly mode
    $field_id = Html::cleanId("dropdown_" . $name . $param['rand']);
    if ($param['readonly']) {
      $to_display = [];
      foreach ($param['values'] as $value) {
        $output .= "<input type='hidden' name='$field_name' value='$value'>";
        if (isset($elements[$value])) {
          $to_display[] = $elements[$value];
        }
      }
      $output .= implode('<br>', $to_display);
    } else {

      $output  .= "<select name='$field_name' id='$field_id'";

      if ($param['tooltip']) {
        $output .= ' title="' . Html::entities_deep($param['tooltip']) . '"';
      }

      if ($param['class']) {
        $output .= ' class="' . Html::entities_deep($param['class']) . '"';
      }

      if (!empty($param["on_change"])) {
        $output .= " onChange='" . $param["on_change"] . "'";
      }

      if ((is_int($param["size"])) && ($param["size"] > 0)) {
        $output .= " size='" . $param["size"] . "'";
      }

      if ($param["multiple"]) {
        $output .= " multiple";
      }

      if ($param["disabled"]) {
        $output .= " disabled='disabled'";
      }

      $output .= '>';
      $max_option_size = 0;
      foreach ($elements as $key => $val) {
        if (is_array($val)) {
          $opt_goup = Html::entities_deep($key);
          if ($max_option_size < strlen($opt_goup)) {
            $max_option_size = strlen($opt_goup);
          }

          foreach ($val as $key2 => $val2) {
            if (!isset($param['used'][$key2])) {
              $output .= "<option value='" . $key2 . "'";
              // Do not use in_array : trouble with 0 and empty value
              foreach ($param['values'] as $value) {
                if (strcmp($key2, $value) === 0) {
                  $output .= " selected";
                  break;
                }
              }
              $output .= ">" .  Html::entities_deep($val2) . "</option>";
              if ($max_option_size < strlen($val2)) {
                $max_option_size = strlen($val2);
              }
            }
          }
        } else {
          if (!isset($param['used'][$key])) {
            $output .= "<option value='" . Html::entities_deep($key) . "'";
            // Do not use in_array : trouble with 0 and empty value
            foreach ($param['values'] as $value) {
              if (strcmp($key, $value) === 0) {
                $output .= " selected";
                break;
              }
            }
            if (isset($param['option_tooltips'][$key])) {
              $output .= ' title="' . $param['option_tooltips'][$key] . '"';
            }
            $output .= ">" . Html::entities_deep($val) . "</option>";
            if ($max_option_size < strlen($val)) {
              $max_option_size = strlen($val);
            }
          }
        }
      }

      if ($param['other'] !== false) {
        $output .= "<option value='$other_select_option'";
        if (is_string($param['other'])) {
          $output .= " selected";
        }
        $output .= ">" . __('Other...') . "</option>";
      }

      $output .= "</select>";
      if ($param['other'] !== false) {
        $output .= "<input name='$other_select_option' id='$other_select_option' type='text'";
        if (is_string($param['other'])) {
          $output .= " value=\"" . $param['other'] . "\"";
        } else {
          $output .= " style=\"display: none\"";
        }
        $output .= ">";
      }
    }

    if (!$param['noselect2']) {
      // Width set on select
      $output .= Html::jsAdaptDropdown($field_id, ['width' => $param["width"]]);
    }

    if ($param["multiple"]) {
      // Hack for All / None because select2 does not provide it
      $select   = __('All');
      $deselect = __('None');
      $output  .= "<div class='invisible' id='selectallbuttons_$field_id'>";
      $output  .= "<div class='select2-actionable-menu'>";
      $output  .= "<a class='vsubmit' " .
        "onclick=\"selectAll('$field_id');$('#$field_id').select2('close');\">$select" .
        "</a> ";
      $output  .= "<a class='vsubmit floatright' onclick=\"deselectAll('$field_id');\">$deselect" .
        "</a>";
      $output  .= "</div></div>";

      $js = "
         var multichecksappend$field_id = false;
         $('#$field_id').on('select2:open', function(e) {
            if (!multichecksappend$field_id) {
               $('#select2-$field_id-results').parent().append($('#selectallbuttons_$field_id').html());
               multichecksappend$field_id = true;
            }
         });";
      $output .= Html::scriptBlock($js);
    }

    $output .= Ajax::commonDropdownUpdateItem($param, false);

    return $output;
  }

  function showForm($ID, array $options = []) // Formulário
  {
    global $DB;

    $validate_whatsapp = '';
    $csrf_token = Session::getNewCSRFToken();

    if (strlen($this->fields['token']) == 36 && $ID > 0) {
      $validate_whatsapp = Html::submit(
        _x('button', 'Validar'),
        ['name' => 'validate']
      );
    }

    $template = new ChatcorpTemplate();
    $section_integration_form_values = array();
    $integration_form_values = array(
      'CSRF' => $csrf_token,
      'BUTTON_SUBMIT' => '',
      "SECTION_ENTITY" => '',
      'FORM_ACTION' => Toolbox::getItemTypeFormURL(__CLASS__),
      'BUTTON_VALIDATE_APIKEY' => $validate_whatsapp,
      'ITEM_ID_VALUE' => $ID,
      'ITEM_NUMBER_VALUE' => $this->fields['number'] ?? '',
      'ITEM_APIKEY_VALUE' => $this->fields['token'] ?? null,
      'ITEM_DESCRIPTION_VALUE' => $this->fields['description'] ?? null,
      'WHATSAPP_IN_USE' => $this->fields['number'] ?? "não configurado."
    );

    if ($ID > 0 && !empty($this->fields['token']) && empty($this->fields['number'])) {
      $section_integration_form_values['TITLE'] = 'Seu token é inválido ou você ainda não leu o QRCode, vá até o <b>painel da API do ChatCorp</b> para gerenciar sua integração.';
    } else {
      $section_integration_form_values['TITLE'] = '<b>Configuração do plugin</b>';
    }

    if ($ID <= 0) {
      $integration_form_values['BUTTON_SUBMIT'] = Html::submit(
        _x('button', 'Adicionar'),
        ['name' => 'add']
      );
    } else {
      $entity_section_values = [
        "TITLE" => '',
        "CONTENT" => ''
      ];

      if (isset($this->fields['number']) && !empty($this->fields['number'])) {
        $entity_data = [];
        $entities = [];

        foreach ($DB->request("SELECT id,name FROM glpi_entities") as $row) {
          $id = $row['id'];
          $name = $row['name'];

          array_push($entity_data, [$id => $name]);
        }

        if ($ID > 0) {
          foreach ($DB->request("SELECT entity_id FROM glpi_plugin_chatcorp_entities WHERE wts_id = $ID") as $row) {
            array_push($entities, $row['entity_id']);
          }
        }

        $entity_select_values = [
          "CONTENT" => self::showFromArray("entities_id", $entity_data, ['values' => $entities, 'width' => '350px', 'multiple' => 'multiple']),
          "TITLE" => ''
        ];

        $entity_select_values['TITLE'] .= $template->parse('components/radio_button', [
          "ID" => 'chatcorp_use_all_entities',
          "LABEL" => 'Utilizar todas as entidades',
          "NAME" => 'use_all_entities',
          "VALUE" => '1',
          "CHECKED" => $this->fields['use_all_entities'] ? 'checked' : '',
        ]);
        $entity_select_values['TITLE'] .= $template->parse('components/radio_button', [
          "ID" => 'chatcorp_use_list_entities',
          "LABEL" => 'Apenas as entidades na lista:',
          "NAME" => 'use_all_entities',
          "VALUE" => '0',
          "CHECKED" => !$this->fields['use_all_entities'] ? 'checked' : '',
        ]);

        $entity_section_values = [
          "TITLE" => 'Entidades que utilizarão este canal',
          "CONTENT" => $template->parse('patterns/entity_select', $entity_select_values)
        ];
      }

      $integration_form_values['SECTION_ENTITY'] = $template->parse('components/section', $entity_section_values);
      $integration_form_values['BUTTON_SUBMIT'] .= Html::submit(
        _x('button', 'Salvar'),
        ['name' => 'update']
      );

      $integration_form_values['BUTTON_SUBMIT'] .= Html::submit(
        _x('button', 'Deletar'),
        [
          'name'    => 'delete',
          'confirm' => __('Ao clicar em confirmar o registro será excluído.')
        ]
      );
    }

    $section_test_form = '';

    if ($ID > 0 && isset($this->fields['number']) && !empty($this->fields['number'])) {
      $test_form_values = [
        'CSRF' => $csrf_token,
        'FORM_ACTION' => Toolbox::getItemTypeFormURL(__CLASS__),
        'ITEM_ID_VALUE' => $ID,
        'ITEM_NUMBER_VALUE' => $this->fields['number'],
        'ITEM_APIKEY_VALUE' => $this->fields['token'],
        'BUTTON_SUBMIT' => ''
      ];

      $test_form_values['BUTTON_SUBMIT'] .= Html::submit(
        _x('button', 'Enviar mensagem teste'),
        ['name' => 'testmessage']
      );
      $test_form_values['BUTTON_SUBMIT'] .= Html::submit(
        _x('button', 'Enviar notificação de teste'),
        ['name' => 'testnotification']
      );

      $section_test_form = $template->parse('components/section', [
        'TITLE' => 'Enviar mensagem de teste',
        'CONTENT' => $template->parse('patterns/test_form', $test_form_values),
      ]);
    }

    $header = $template->parse('header', [
      "APP_URL" => APP_URL,
    ]);

    $section_integration_form_values['CONTENT'] = $template->parse('patterns/integration_form', $integration_form_values);
    $section_integration_form = $template->parse('components/section', $section_integration_form_values);

    $footer_values = [
      "APP_URL" => APP_URL,
    ];
    $footer_values['INFO_TEST'] = $template->parse('components/info', [
      'CONTENT' => 'Com exceção do teste, os envios são todos agendados e enviado 10 mensagens a cada minuto, para reduzir o risco de bloqueio do seu número.'
    ]);
    $footer_values['INFO_NUMBER'] = $template->parse('components/info', [
      'CONTENT' => 'No cadastro do usuário, no campo <b>celular</b> deve conter o número de Whatsapp no padrão DDI+DDD+Número (conforme o exemplo do teste acima).'
    ]);
    $footer = $template->parse('footer', $footer_values);

    $base_content_values = [
      "HEADER" => $header,
      "FOOTER" => $footer,
      "CONTENT" => ''
    ];
    $base_content_values['CONTENT'] .= $section_integration_form;
    $base_content_values['CONTENT'] .= $section_test_form;

    $base_content = $template->parse('base', $base_content_values);
    echo $base_content;

    return true;
  }

  /**
   * Função para adicionar as entidades em uma tabela separada
   *
   *
   */
  function setEntities($ID, $entities)
  {
    global $DB;

    $all_entities = [];

    foreach ($DB->request("SELECT entity_id FROM glpi_plugin_chatcorp_entities WHERE wts_id = $ID") as $row) {
      array_push($all_entities, $row['entity_id']);
    }

    if (!$entities) {
      $entities = [];
    }

    $diff = array_diff($all_entities, $entities); // Caso tenha entidades para serem removidas
    if (!empty($diff)) {
      foreach ($diff as $entity_id) {
        $query = "DELETE FROM `glpi_plugin_chatcorp_entities`
               WHERE wts_id = $ID AND entity_id = $entity_id";
        $DB->queryOrDie($query, $DB->error());
      }
    }

    $diff = array_diff($entities, $all_entities); // Caso tenha novas entidades para serem adicionadas
    if (!empty($diff)) {
      foreach ($diff as $entity_id) {
        $query = "INSERT INTO `glpi_plugin_chatcorp_entities`
               (`entity_id`, `wts_id`)
               VALUES ($entity_id, $ID)";
        $DB->queryOrDie($query, $DB->error());
      }
    }
  }

  /**
   * Função para enviar mensagem de teste
   *
   *
   */
  function sendTest($token, $number)
  {
    $curl = curl_init();

    $testResult = [
      'success' => false,
      'error' => null,
    ];

    try {
      curl_setopt_array($curl, array(
        CURLOPT_URL => API_URL . '/srvc/w/send/test',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode([
          "number" => $number,
          "message" => "Olá, este é um teste de mensagem do GLPi"
        ]),
        CURLOPT_HTTPHEADER => array(
          "Content-Type: application/json",
          "apikey: {$token}"
        ),
      ));

      $request = curl_exec($curl);
      $resp = json_decode($request ?? '{}');

      if (!empty($resp->error)) {
        $testResult['error'] = 'Ocorreu um problema ao realizar o teste de mensagem! Verifique os dados da licença e tente novamente.';
      }

      $testResult['success'] = $resp->success ?? false;
    } catch (Exception $e) {
      $testResult['error'] = $e->getMessage();
    }

    return $testResult;
  }

  /**
   * Função para pegar o número usado na licença
   *
   *
   */
  function setNumber($token)
  {
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => API_URL . '/srvc/w/deviceinfo',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_SSL_VERIFYHOST => false,
      CURLOPT_SSL_VERIFYPEER => false,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HTTPHEADER => array(
        "apikey: {$token}"
      ),
    ));

    $resp = json_decode(curl_exec($curl));

    if (curl_errno($curl)) {
      $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (!empty($resp->phone->number)) {
      $number = $resp->phone->number;
      return $number;
    } else {
      Session::addMessageAfterRedirect($resp->error ?? $error_msg);
    }

    return null;
  }

  /**
   * Função para pegar o token atual
   *
   *
   */
  function getCurrentToken($ID)
  {
    global $DB;
    $pluralizedTableName = getPluralChatcorpTableName('chatcorp');

    $iterator = $DB->request("SELECT token FROM glpi_plugin_chatcorp_$pluralizedTableName WHERE id = '{$ID}'");
    $wts = version_compare(GLPI_VERSION, '10.0.0', '<') ? $iterator->next() : $iterator->current();

    $token = $wts['token'];
    return $token;
  }

  static function getInstance($type)
  {

    $class = 'PluginChatcorpChatcorp' . $type;
    if (class_exists($class)) {
      return new $class();
    }
    return false;
  }

  function rawSearchOptions()
  {
    $tab = parent::rawSearchOptions();
    $table = $this->getTable();

    $tab[] = [
      'id'                 => '1',
      'table'              => $table,
      'field'              => 'token',
      'name'               => __('Apikey'),
      'massiveaction'      => true
    ];

    $tab[] = [
      'id'            => '20',
      'table'         => $table,
      'field'         => 'number',
      'name'          => __('Número'),
    ];

    $tab[] = [
      'id'            => '30',
      'table'         => $table,
      'field'         => 'description',
      'name'          => __('Descrição'),
    ];

    $tab[] = [
      'id'            => '40',
      'table'         => $table,
      'field'         => 'use_all_entities',
      'datatype'      => 'bool',
      'name'          => __('Utiliza todas as entidades'),
    ];

    return $tab;
  }

  function getSpecificMassiveActions($checkitem = null)
  {

    $actions = parent::getSpecificMassiveActions($checkitem);

    $actions[__CLASS__ . MassiveAction::CLASS_ACTION_SEPARATOR . 'delete'] =
      _x('button', 'Excluir registros');  // Specific one

    return $actions;
  }

  static function processMassiveActionsForOneItemtype(
    MassiveAction $ma,
    CommonDBTM $item,
    array $ids
  ) {
    global $DB;
    $pluralizedTableName = getPluralChatcorpTableName('chatcorp');

    switch ($ma->getAction()) {
      case 'delete':
        foreach ($ids as $id) {
          $DB->delete("glpi_plugin_chatcorp_$pluralizedTableName", ['id' => $id]);
        }

        $ma->itemDone($item->getType(), $id, MassiveAction::ACTION_OK);

        return;
    }

    parent::processMassiveActionsForOneItemtype($ma, $item, $ids);
  }
}
