<?php

class ChatcorpTemplate
{
  private $template_directory = __DIR__ . '/../template/';
  public function __construct()
  {
  }

  public function load(string $template_name)
  {
    $template_path = $this->template_directory . $template_name;
    $content = '';

    $file = str_ends_with($template_path, '.html') ? $template_path : $template_path . '.html';

    if (is_file($file)) {
      $content = file_get_contents($file);
    } else if (is_dir($template_path)) {
      $content = file_get_contents($template_path . '/index.html');
    }

    return $content;
  }

  public function parse(string $template_name, array $values)
  {
    $template = $this->load($template_name);
    $parsedTemplate = $template;

    if ($template) {
      foreach ($values as $key => $value) {
        $parsedTemplate = str_replace("{{ $key }}", $value, $parsedTemplate);
      }
    }

    return $parsedTemplate;
  }
}
