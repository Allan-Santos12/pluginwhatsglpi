<?php

class PluginChatcorpNotificationWhatsappSetting extends NotificationSetting
{
  const MODE_WHATSAPP = "whatsapp"; // Criando modo personalizado para notificação personalizada

  static public function getTypeName($nb = 0)
  {
    return __('ChatCorp configuration');
  }

  public function getEnableLabel()
  {
    return __('API ChatCorp (WhatsApp)');
  }


  static public function getMode()
  {
    return self::MODE_WHATSAPP;
  }


  function showFormConfig()
  {
    Html::redirect(Toolbox::getItemTypeSearchURL('PluginChatcorpChatcorp'));
  }
}
