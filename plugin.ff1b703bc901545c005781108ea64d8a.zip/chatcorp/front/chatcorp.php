<?php

include('../../../inc/includes.php');

Html::header(PluginChatcorpChatcorp::getTypeName(), $_SERVER['PHP_SELF'], "plugins", "PluginChatcorpChatcorp", "");

if (!isset($_SESSION['glpiname'])) {
  echo "<center><h3>Você não tem permissão para acessar este recurso!</h3></center>";
  die;
}
Search::show('PluginChatcorpChatcorp');

Html::footer();
