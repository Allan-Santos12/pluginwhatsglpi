<?php

require_once(__DIR__ . '/inc/constants.php');
// Habilitar cron do glpi
// define('GLPI_SYSTEM_CRON', true);

/**
 * Função de setup
 */
function plugin_version_chatcorp()
{
  return array(
    'name'           => "Chat Corp",
    'version'        => HU3_PLUGIN_VERSION,
    'author'         => "<a href='" . APP_URL . "' target='_blank'>Chat Corp</a>",
    'license'        => 'GPLv3+',
    'homepage'       => APP_URL
  );
}

/**
 * Função de inicialização
 */
function plugin_init_chatcorp()
{
  global $PLUGIN_HOOKS;
  $plugin = new Plugin();

  // Ativar botão de habilitar plugin
  $PLUGIN_HOOKS['csrf_compliant']['chatcorp'] = true;

  $_SESSION["glpi_plugin_chatcorp_profile"]['chatcorp'] = 'w';

  // Adicionar botão na aba Plugins
  if (isset($_SESSION["glpi_plugin_chatcorp_profile"])) {
    $PLUGIN_HOOKS['menu_toadd']['chatcorp'] = ['plugins' => 'PluginChatcorpChatcorp'];
  }

  if ($plugin->isActivated('chatcorp')) {
    Notification_NotificationTemplate::registerMode(
      PluginChatcorpNotificationWhatsappSetting::MODE_WHATSAPP, //mode itself
      __('API ChatCorp', 'plugin_chatcorp'),             //label
      'chatcorp'                                    //plugin name
    );
  }
}

/**
 * Verificar versão
 */
function plugin_chatcorp_check_prerequisites()
{
  if (version_compare(GLPI_VERSION, '9.4', '>=')) {
    return true;
  } else {
    echo "GLPI version NOT compatible. Requires GLPI >= 9.4";
  }
}

/**
 * @return boolean
 */
function plugin_chatcorp_check_config()
{
  // Ao retornar false o glpi exibe uma mensagem de que o plugin deve ser configurado
  return true;
}
