<?php

require_once(__DIR__ . '/inc/notificationtemplates.php');
require_once(__DIR__ . '/inc/constants.php');
require_once(__DIR__ . '/utils/string.php');

/**
 * @return boolean
 */
function plugin_chatcorp_install()
{
  global $DB;

  echo "Current GLPI Version: " . GLPI_VERSION;
  echo "Current Plugin Version: " . HU3_PLUGIN_VERSION;
  $isNewerGlpi = version_compare(GLPI_VERSION, '10.0.0', '>=');

  $charset = 'utf8';
  $collate = 'utf8_unicode_ci';
  $key_sign = '';

  if ($isNewerGlpi) {
    $charset = 'utf8mb4';
    $collate = 'utf8mb4_general_ci';
    $key_sign = 'UNSIGNED';
  }

  $pluralizedTableName = getPluralChatcorpTableName('chatcorp');

  if (!$DB->tableExists("glpi_plugin_chatcorp_$pluralizedTableName")) {
    // Criar tabela do plugin
    $query = "CREATE TABLE `glpi_plugin_chatcorp_$pluralizedTableName` (
            `id` INT {$key_sign} NOT NULL auto_increment,
            `token` VARCHAR(36) NOT NULL,
            `number` VARCHAR(20) NULL,
            `description` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=$charset COLLATE=$collate";

    $DB->queryOrDie($query, $DB->error());
  }

  if (!$DB->tableExists("glpi_plugin_chatcorp_entities")) {
    // Criar tabela das entidades
    $query = "CREATE TABLE `glpi_plugin_chatcorp_entities` (
            `id` INT {$key_sign} NOT NULL auto_increment,
            `entity_id` INT {$key_sign} NOT NULL DEFAULT '0',
            `wts_id` INT {$key_sign} NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`),
            CONSTRAINT FOREIGN KEY (`wts_id`) REFERENCES `glpi_plugin_chatcorp_$pluralizedTableName`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
        ) ENGINE=InnoDB  DEFAULT CHARSET=$charset COLLATE=$collate";
    $DB->queryOrDie($query, $DB->error());
  }

  if (!$DB->tableExists("glpi_plugin_chatcorp_messages")) {
    $iterator = $DB->request("SELECT NUMERIC_PRECISION, UPPER(data_type) AS DATA_TYPE FROM information_schema.columns WHERE `table_name` LIKE '%glpi_tickets' AND `column_name` = 'id' LIMIT 1");

    $table_info = version_compare(GLPI_VERSION, '10.0.0', '<') ? $iterator->next() : $iterator->current();

    $ticket_id_data_type = $table_info['DATA_TYPE'] ?? 'INT';

    echo "Ticket Data Type" . $table_info['DATA_TYPE'];
    echo "Ticket Display Width" . $table_info['NUMERIC_PRECISION'];

    // Criar tabela de envios
    $query = "CREATE TABLE `glpi_plugin_chatcorp_messages` (
            `id` INT {$key_sign} NOT NULL auto_increment,
            `message_id` VARCHAR(255) NOT NULL,
            `ticket_id` {$ticket_id_data_type} {$key_sign} NOT NULL,
            PRIMARY KEY (`id`),
            CONSTRAINT FOREIGN KEY (`ticket_id`) REFERENCES `glpi_tickets`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
        ) ENGINE=InnoDB  DEFAULT CHARSET=$charset COLLATE=$collate";

    $DB->queryOrDie($query, $DB->error());
  }

  if ($DB->tableExists("glpi_requesttypes")) {
    // Criar tabela de envios
    $iterator = $DB->request("SELECT * FROM `glpi_requesttypes` WHERE COMMENT = 'WhatsApp';");

    if (sizeof($iterator) == 0) {
      $query = "INSERT INTO `glpi_requesttypes`
                              (`name`, `comment`)
                       VALUES ('WhatsApp', 'WhatsApp');";
      $DB->queryOrDie($query, $DB->error());
    }
  }

  $column_version = $DB->request("SELECT * FROM information_schema.columns WHERE TABLE_NAME = 'glpi_plugin_chatcorp_$pluralizedTableName' AND COLUMN_NAME = 'use_all_entities'");
  if (sizeof($column_version) == 0) {
    $query = "ALTER TABLE `glpi_plugin_chatcorp_$pluralizedTableName`
        ADD COLUMN use_all_entities BOOLEAN NOT NULL";
    $DB->queryOrDie($query, $DB->error());
    $query = "ALTER TABLE `glpi_plugin_chatcorp_$pluralizedTableName`
        ALTER COLUMN use_all_entities SET DEFAULT 0";
    $DB->queryOrDie($query, $DB->error());
    $query = "UPDATE `glpi_plugin_chatcorp_$pluralizedTableName` SET use_all_entities = 0";
    $DB->queryOrDie($query, $DB->error());
  }

  if (!$DB->tableExists("glpi_plugin_chatcorp_configs")) {
    // Criar tabela das entidades
    $query = "CREATE TABLE glpi_plugin_chatcorp_configs (
      `type` VARCHAR(50) NOT NULL,
      `value` VARCHAR(50) NOT NULL,
      PRIMARY KEY (`type`)
    ) ENGINE=InnoDB DEFAULT CHARSET=$charset COLLATE=$collate";
    $DB->queryOrDie($query, $DB->error());

    $query = "INSERT INTO `glpi_plugin_chatcorp_configs` (`type`, `value`) VALUES ('version', '1.6.0')";
    $DB->queryOrDie($query, $DB->error());
  }

  $iterator = $DB->request("SELECT * FROM glpi_notifications_notificationtemplates WHERE mode = 'whatsapp'");
  if (sizeof($iterator) == 0) {
    manageChatcorpNotificationTemplates(); // Criando templates de notificação
  }

  Config::setConfigurationValues('core', ['notifications_whatsapp' => 1]);

  // $migration->executeMigration();

  return true;
}

/**
 * @return boolean
 */
function plugin_chatcorp_uninstall()
{
  $config = new Config();

  $config->deleteConfigurationValues('core', ['notifications_whatsapp']);

  return true;
}

function plugin_chatcorp_giveItem($type, $ID, $data, $num)
{
  $searchopt = &Search::getOptions($type);

  $table = $searchopt[$ID]["table"];
  $field = $searchopt[$ID]["field"];

  $pluralizedTableName = getPluralChatcorpTableName('chatcorp');

  switch ($table . '.' . $field) {
    case "glpi_plugin_chatcorp_$pluralizedTableName.token":
      $out = "<a href='" . Toolbox::getItemTypeFormURL('PluginChatcorpChatcorp') . "?id=" . $data['id'] . "'>";
      $out .= $data[$num][0]['name'];

      $out .= "</a>";
      return $out;
  }

  return "";
}

function manageChatcorpNotificationTemplates()
{
  global $DB;
  foreach (TEMPLATES as $name => $notify) {
    $query_template = "INSERT INTO `glpi_notificationtemplates`
                      (`name`, `itemtype`, `date_mod`)
               VALUES ('{$name}', '{$notify["type"]}', NOW())";

    $query_notify = "INSERT INTO `glpi_notifications`
                      (`name`, `itemtype`, `event`, `is_recursive`, `is_active`)
               VALUES ('{$name}', '{$notify["type"]}', '{$notify["event"]}', 1, 1)";

    if (!method_exists($DB, "insertId")) {
      $DB->queryOrDie($query_template, $DB->error());
      $templateid = $DB->insert_id();
      $DB->queryOrDie($query_notify, $DB->error());
      $notificationid = $DB->insert_id();
    } else {
      $DB->queryOrDie($query_template, $DB->error());
      $templateid = $DB->insertId();
      $DB->queryOrDie($query_notify, $DB->error());
      $notificationid = $DB->insertId();
    }

    foreach ($notify['targets'] as $type => $target) {
      foreach ($target as $items_id) {
        $query = "INSERT INTO `glpi_notificationtargets`
                              (`items_id`, `type`, `notifications_id`)
                       VALUES ($items_id, $type, '{$notificationid}')";
        $DB->queryOrDie($query, $DB->error());
      }
    }

    $query = "INSERT INTO `glpi_notifications_notificationtemplates`
                      (`notifications_id`, `notificationtemplates_id`, `mode`)
               VALUES ('{$notificationid}', '{$templateid}', 'whatsapp')";
    $DB->queryOrDie($query, $DB->error());

    $query = "INSERT INTO `glpi_notificationtemplatetranslations`
                      (`notificationtemplates_id`, `subject`, `content_text`)
               VALUES ('{$templateid}', '{$notify["subject"]}', '{$notify["content_text"]}')";
    $DB->queryOrDie($query, $DB->error());
  }
}
